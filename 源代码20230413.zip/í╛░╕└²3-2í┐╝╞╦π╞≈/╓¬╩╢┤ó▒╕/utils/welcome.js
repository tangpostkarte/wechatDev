module.exports = {
  message: 'welcome'
}
