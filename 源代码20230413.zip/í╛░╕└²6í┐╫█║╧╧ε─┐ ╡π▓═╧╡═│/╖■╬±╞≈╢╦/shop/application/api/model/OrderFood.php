<?php
namespace app\api\model;

use think\Model;

class OrderFood extends Model
{
}
