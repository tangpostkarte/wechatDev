<?php
return [
    'url_common_param' => true
];
