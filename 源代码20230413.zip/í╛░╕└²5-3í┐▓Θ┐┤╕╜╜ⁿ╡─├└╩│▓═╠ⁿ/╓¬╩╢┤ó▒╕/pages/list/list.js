// pages/list/list.js
Page({
  onLoad: function(options) {
    console.log(options)
  }
})